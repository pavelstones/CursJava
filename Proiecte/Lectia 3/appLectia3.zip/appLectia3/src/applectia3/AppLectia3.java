package applectia3;

/* @author vasile */
public class AppLectia3 {

    public static void main(String[] args) {
        
        Radio r = new Radio(10);
        r.porneste();
        r.stare();
        r.porneste();
        
/*      r.daMaiTare();
        r.stare();
        r.daMaiTare(3);
        r.stare();
        r.daMaiTare(10);
        r.stare();*/
        
/*      r.postUrmator();
        r.postUrmator();
        r.postUrmator();
        r.postUrmator();
        r.postUrmator();
        r.postUrmator();
        r.postUrmator();
        r.postUrmator();
        r.postUrmator();
        r.stare();*/

        r.postPrecedent();
        r.postPrecedent();
        r.postPrecedent();
        r.postPrecedent();
        r.postPrecedent();
        r.postPrecedent();
        r.postPrecedent();
        r.postPrecedent();
        r.postPrecedent();
        r.postPrecedent();
        r.postPrecedent();
        r.postPrecedent();
        r.stare();
        
        r.opreste();
        r.opreste();
        
        
        Radio r0 = new Radio();
    }
    
}
