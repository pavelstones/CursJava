/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modificatori1;

/**
 *
 * @author instructor
 */
public class A {
    public int x;
    private int y;
    protected int z;
    int t;
    
    void f(){
        x = 1;
        y = 1;
        z = 1;
        t = 1;
    }
}
