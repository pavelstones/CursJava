/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modificatori1;

/**
 *
 * @author instructor
 */
public class B {
    void f(){
        A a1 = new A();
        a1.x = 10;
        a1.y = 10;
        a1.z = 10;
        a1.t = 10;
    }
}
