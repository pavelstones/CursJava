/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

/**
 *
 * @author instructor
 */
public class Pistol {

    boolean piedica = true;
    private int nrGloante;
    int MAXG = 20;

    void punePiedica() {
        if (piedica) {
            System.out.println("Piedica e deja pusa!");
        } else {
            piedica = true;
            System.out.println("S-a pus piedica");
        }
    }

    void scoatePiedica() {
        if (!piedica) {
            System.out.println("Piedica e deja scoasa");
        } else {
            piedica = false;
            System.out.println("Ati scos piedica");
        }
    }

    void trage() {
        trage(1);
    }

    void trage(int n) {
        if (piedica) {
            System.out.println("Nu puteti trage cu piedica pusa");
            return;
        }

        if (nrGloante < n) {
            System.out.println("Nu aveti suficiente gloante");
            return;
        }

        nrGloante -= n;
        System.out.print("P");
        for (int i = 0; i < n; i++) {
            System.out.print("O");
        }
        System.out.println("C");
    }

    void incarca() {
        if (nrGloante == MAXG) {
            System.out.println("E deja full");
        } else {
            nrGloante = MAXG;
            System.out.println("Ati reincarcat");
        }
    }

    void stare() {
        System.out.println("Piedica este " + (piedica ? "pusa" : "scoasa"));
        System.out.println("Mai aveti " + nrGloante + " gloante");
    }

}

class X {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int intArr[] = {0, 4, 2, 5, 3};
        char ch = '2';
        System.out.println("ch: " + ch);
        System.out.println("intArr[" + intArr[ch]);
        Pistol p = new Pistol();
        p.trage();
        p.punePiedica();
        p.scoatePiedica();
        p.trage();
        p.incarca();
        p.trage();
        p.trage();
        p.trage();
        p.trage();

//        p.nrGloante = -10;
        p.trage();
        p.trage(10);

    }

}
